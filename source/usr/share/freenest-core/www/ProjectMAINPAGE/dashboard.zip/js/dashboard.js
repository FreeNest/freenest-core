$(document).ready(function(){
  $("div.menu ul li.grey ul").slideDown();
  $("div#activity ul li.silver ul").slideDown();
  
  $("div.menu ul li").click(function(){
    var ul = $(this).find('ul'); 
    if(ul.css('display') === 'block') {
      ul.slideUp();
    }else ul.slideDown();
  });
});